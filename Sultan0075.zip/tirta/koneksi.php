<?php
ini_set('max_execution_time', 300); 
    //open connection to mysql db
    $koneksi = mysqli_connect("localhost","root","","stbi_uu") or die("Error " . mysqli_error($koneksi));
?>