<div class="">
	<div class="clearfix"></div>
<br>
	<form action='hasil_pencarian.php' method='GET'>
    	
        <center> 
        	<h3>STBI Undang-Undang</h3><br>
      </center>
     <div class="form-group">
                        <label class="col-sm-3 control-label"></label>

                        <div class="col-sm-7">
                          <div class="input-group">
                            <input class="form-control" type="text" name='keyword' placeholder="masukkan keyword . . .">
                            <span class="input-group-btn">
                                              <input class="btn btn-primary" type='submit' value='Cari'>
                                          </span>
                          </div>
                        </div>
                      </div>
     </form>
     	</div>
</div>