<div class="">
	<div class="clearfix"></div>
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
				<div class="x_title">
					<h2>ANGGOTA KELOMPOK</h2>
					<div class="clearfix"></div>
				</div>
				<div class="x_content">
					<H3>1). 15.01.63.0018 Afandi</H3>
					<H3>1). 16.01.63.0023 Dedi Widiarto</H3>
					<H3>1). 14.01.53.0130 Alfad Aifudin Zuhri</H3>
				</div>
			</div>
		</div>
	</div>
</div>